let hello = 'hello';
console.log(hello);
document.write(`${hello} `);
alert(hello);

let owu = 'owu';
console.log(owu);
document.write(`${owu}.`);
alert(owu);

let com = 'com';
console.log(com);
document.write(`${com}.`);
alert(com);

let ua = 'ua';
console.log(ua);
document.write(`${ua} `);
alert(ua);

let n1 = '1';
console.log(n1);
document.write(`${n1} `);
alert(n1)

let n2 = '10';
console.log(n2);
document.write(`${n2} `);
alert(n2);

let n3 = '-999';
console.log(n3);
document.write(`${n3} `);
alert(n3);

let n4 = '123';
console.log(n4);
document.write(`${n4} `);
alert(n4);

let n5 = '3.14';
console.log(n5);
document.write(`${n5} `);
alert(n5);

let n6 = '2.7';
console.log(n6);
document.write(`${n6} `);
alert(n6);

let n7 = '16';
console.log(n7);
document.write(`${n7} `);
alert(n7);

let b1= 'true';
console.log(b1);
document.write(`${b1} `);
alert(b1);

let b2= 'false';
console.log(b2);
document.write(b2);
alert(b2);