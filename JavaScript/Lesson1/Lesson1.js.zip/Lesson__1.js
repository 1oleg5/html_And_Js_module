let name = prompt('Enter name');
let middleName = prompt('Enter middleName');
let age = +prompt('Enter age');
console.log(name);
console.log(middleName);
console.log(age);