let firstName = 'Oleg';
let middleName = 'Vasyliovych';
let lastName = 'Panchuk';
let res = firstName+' '+middleName+' '+lastName;
console.log(res)